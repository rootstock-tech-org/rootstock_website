"use client";

import { useRef } from 'react';
import CarouselNavigation from './CarouselNavigation';

export default function EthicsSection() {
  const ethicsCarouselRef = useRef<HTMLDivElement>(null);

  const handlePrevClick = () => {
    if (ethicsCarouselRef.current) {
      const scrollAmount = ethicsCarouselRef.current.clientWidth * 0.5;
      ethicsCarouselRef.current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    }
  };

  const handleNextClick = () => {
    if (ethicsCarouselRef.current) {
      const scrollAmount = ethicsCarouselRef.current.clientWidth * 0.5;
      ethicsCarouselRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };
  const ethicalPrinciples = [
    {
      icon: "🎯",
      principle: "We don't push trades or churn.",
      color: "from-[#7AE582] to-[#16BAC5]"
    },
    {
      icon: "🆓",
      principle: "Free plan with summaries & Q&A. Advanced features later.",
      color: "from-[#16BAC5] to-[#5FBFF9]"
    },
    {
      icon: "🔍",
      principle: "Every suggestion shows risk level & confidence score.",
      color: "from-[#5FBFF9] to-[#0B3762]"
    },
    {
      icon: "🛡️",
      principle: "No ads. No third-party sharing. No selling user data — ever.",
      color: "from-[#0B3762] to-[#7AE582]"
    }
  ];

  return (
    <section id="ethics" className="bg-gray-800 section section--divider divider-dark">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Ethics & Trust</h2>
          <p className="text-xl text-gray-200 max-w-3xl mx-auto mb-8">
            Trust isn't a feature. It's the foundation.
          </p>
        </div>
        
        {/* Ethical Stand */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-[#7AE582] mb-4">Our Ethical Stand</h3>
          </div>
          {/* Marquee container */}
          <div className="group relative overflow-hidden max-w-6xl mx-auto carousel-container" role="region" aria-label="Our Ethical Stand carousel">
            {/* Edge masks */}
            <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-gray-800 to-transparent z-10" aria-hidden="true"></div>
            <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-gray-800 to-transparent z-10" aria-hidden="true"></div>
            <CarouselNavigation 
              onPrevClick={handlePrevClick}
              onNextClick={handleNextClick}
            />
            <div ref={ethicsCarouselRef} className="overflow-x-auto scroll-smooth" style={{ WebkitOverflowScrolling: 'touch' }} tabIndex={0}>
              <div className="slider-track flex gap-6 focus-within:[animation-play-state:paused]">
                {[...ethicalPrinciples, ...ethicalPrinciples].map((item, index) => (
                  <div
                    key={index}
                    className="min-w-[260px] md:min-w-[300px] lg:min-w-[320px] group bg-white/10 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-white/20 text-center hover:shadow-2xl transition-shadow duration-300"
                  >
                    <div className={`w-16 h-16 bg-gradient-to-r ${item.color} rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4 shadow-lg`}>
                      {item.icon}
                    </div>
                    <p className="text-white font-medium text-lg leading-relaxed">{item.principle}</p>
                  </div>
                ))}
              </div>
            </div>
            {/* Carousel styles moved to carousel.css */}
          </div>
        </div>

        {/* Data Privacy & AI Transparency */}
        <div className="grid md:grid-cols-2 gap-16 max-w-6xl mx-auto">
          <div className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-white/20 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:border-[#7AE582]/50 group">
            <h3 className="text-2xl font-bold text-[#7AE582] mb-4 group-hover:scale-105 transition-transform duration-300">Data Privacy Statement</h3>
            <p className="text-white leading-relaxed mb-4 group-hover:text-[#7AE582] transition-colors duration-300">
              Your data belongs to you. We use it only to improve your experience and never sell it to third parties.
            </p>
                          <ul className="text-gray-200 space-y-2">
                <li className="flex items-center group-hover:text-[#7AE582] transition-colors duration-300 delay-100">
                  <span className="mr-2 text-[#7AE582] group-hover:scale-110 transition-transform duration-300">•</span>
                  AES-256 at rest, TLS 1.2+ in transit
                </li>
                <li className="flex items-center group-hover:text-[#7AE582] transition-colors duration-300 delay-200">
                  <span className="mr-2 text-[#7AE582] group-hover:scale-110 transition-transform duration-300">•</span>
                  India data residency (Bangalore/Mumbai DCs)
                </li>
                <li className="flex items-center group-hover:text-[#7AE582] transition-colors duration-300 delay-300">
                  <span className="mr-2 text-[#7AE582] group-hover:scale-110 transition-transform duration-300">•</span>
                  One-click data export & account deletion
                </li>
              </ul>
          </div>
          <div className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-white/20 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:border-[#16BAC5]/50 group">
            <h3 className="text-2xl font-bold text-[#16BAC5] mb-4 group-hover:scale-105 transition-transform duration-300">AI Transparency Report</h3>
            <p className="text-white leading-relaxed mb-4 group-hover:text-[#16BAC5] transition-colors duration-300">
              We believe in explainable AI. Every decision comes with clear reasoning and confidence levels.
            </p>
                          <ul className="text-gray-200 space-y-2">
                <li className="flex items-center group-hover:text-[#16BAC5] transition-colors duration-300 delay-100">
                  <span className="mr-2 text-[#16BAC5] group-hover:scale-110 transition-transform duration-300">•</span>
                  Every answer shows: source documents, confidence (0–100), and explain-why
                </li>
                <li className="flex items-center group-hover:text-[#16BAC5] transition-colors duration-300 delay-200">
                  <span className="mr-2 text-[#7AE582] group-hover:scale-110 transition-transform duration-300">•</span>
                  Regular fairness checks; no optimization for trade volume
                </li>
                <li className="flex items-center group-hover:text-[#16BAC5] transition-colors duration-300 delay-300">
                  <span className="mr-2 text-[#16BAC5] group-hover:scale-110 transition-transform duration-300">•</span>
                  <a href="#sample-explanation" className="underline hover:text-[#7AE582] transition-colors">See a sample explanation</a>
                </li>
              </ul>
          </div>
        </div>

        
      </div>
    </section>
  );
}
