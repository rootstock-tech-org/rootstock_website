import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Allow dev overlay/assets from an external proxy origin in development
  allowedDevOrigins: [
    "https://e9cwq4w7punvx7-3000.proxy.runpod.net",
  ],
};

export default nextConfig;
